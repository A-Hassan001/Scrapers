from collections import OrderedDict
from scrapy import Spider, Request


class LloydsSpider(Spider):
    name = 'lloyds_1'
    base_url = 'https://ldc.lloyds.com/market-directory'
    custom_settings = {
        'CONCURRENT_REQUESTS': 8,
        'FEEDS': {
            'output/ldc_companies1.csv': {
                'format': 'csv',
                'fields': ['Company Name', 'Company Address', 'Phone', 'Fax', 'Web Site',
                           'Company Type', 'Correspondence Address', 'Registered Address'],
            }
        }
    }

    def start_requests(self):
        yield Request(url=self.base_url)

    def parse(self, response, **kwargs):
        company_types = response.css('h2:contains("Company type") + fieldset input[type="hidden"] ::attr(name)').getall()
        for mode in company_types:
            company_types_slug = '=0&'.join(company_types)+'=0'
            url = f"{self.base_url}/results?cobc=&cob=&loc=&ltti=&{company_types_slug}&name=&mode={mode}&b_page=1"
            listing_page_url = url.replace(f'{mode}=0', f'{mode}=1')
            yield Request(url=listing_page_url, callback=self.parse_detail)

    def parse_detail(self, response):
        companies_list = response.css('.contact-details')

        for company_data in companies_list:
            item = OrderedDict()

            item['Company Name'] = company_data.css('h2::text').get('').strip().replace('+', '')
            corresponding_address = self.extract_address(company_data, "Correspondence address")
            registered_address = self.extract_address(company_data, "Registered address")
            if not (corresponding_address or registered_address):
                item['Company Address'] = '\n'.join(x.strip() for x in company_data.css('address ::text').getall() if x.strip())

            item['Phone'] = self.extract_contact_detail(company_data, "Tel:")
            item['Fax'] = self.extract_contact_detail(company_data, "Fax:")
            item['Web Site'] = company_data.css("a[href^='http']::text").get(default='').strip()
            item['Company Type'] = response.css('div.tabs_menu--box--menu-container h3::text').get().strip()
            item['Correspondence Address'] = corresponding_address
            item['Registered Address'] = registered_address
            yield item

        next_anchor = response.css('.active-page + li a::attr(href)').get()
        if next_anchor:
            next_url = response.urljoin(next_anchor)
            yield Request(url=next_url, callback=self.parse_detail)

    def extract_address(self, company_data, heading_text):
        return '\n'.join([x.strip() for x in company_data.css(f'h3:contains("{heading_text}") + address ::text').getall() if x.strip()])

    def extract_contact_detail(self, company_data, label):
        sel = company_data.css(f'span.tel:contains("{label}")')
        return sel.css('a[href^="tel:"]::text').get() or ''.join(sel.css('::text').getall()).replace(label, '').strip()



