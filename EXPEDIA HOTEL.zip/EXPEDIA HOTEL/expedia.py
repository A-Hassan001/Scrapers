import csv
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By


class ExpediaScraper:

    def __init__(self):
        options = Options()
        options.add_argument('start-maximized')
        options.add_experimental_option('detach', True)
        self.driver = webdriver.Chrome(options=options)
        self.driver.implicitly_wait(15)
        self.data = []

    def open_site(self):
        self.driver.get(
            'https://www.expedia.co.jp/Tokyo-Hotels-Shinagawa-Prince-Hotel.h18997.Hotel-Information?chkin=2025-07-17&chkout=2025-07-19&x_pwa=1&rfrr=HSR&pwa_ts=1751428812136&referrerUrl=aHR0cHM6Ly93d3cuZXhwZWRpYS5jby5qcC9Ib3RlbC1TZWFyY2g%3D&useRewards=false&rm1=a2&regionId=3593&destination=%E6%9D%B1%E4%BA%AC%2C+%E6%9D%B1%E4%BA%AC%E9%83%BD%2C+%E6%97%A5%E6%9C%AC&destType=MARKET&neighborhoodId=6048245&selected=18997&latLong=35.681143%2C139.767208&sort=RECOMMENDED&top_dp=20489&top_cur=JPY&userIntent=&selectedRoomType=114831&selectedRatePlan=389686538&searchId=400df795-172f-4a17-9738-581dd5e72400')
        time.sleep(5)

        cards = self.driver.find_elements(By.CSS_SELECTOR, "div[data-stid^='property-offer']")

        for card in cards:
            try:
                room_name = card.find_element(By.CSS_SELECTOR, "h3.uitk-heading").text.strip()

                # total price (before clicking breakfast)
                try:
                    total_price_elem = card.find_element(By.XPATH,
                                                         ".//*[contains(translate(text(),'TOTAL','total'),'total')]")
                    total_price = self.clean_price(total_price_elem.text.strip())
                except:
                    total_price = ""

                # select breakfast if available
                try:
                    breakfast_radio = card.find_element(By.CSS_SELECTOR, 'input[aria-label*="Breakfast buffet, "]')
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", breakfast_radio)
                    time.sleep(2)
                    breakfast_radio.click()
                    time.sleep(2)

                    updated_price_elem = card.find_element(By.XPATH,
                                                           ".//*[contains(translate(text(),'TOTAL','total'),'total')]")
                    breakfast_price_text = self.clean_price(updated_price_elem.text.strip())

                except:
                    breakfast_price_text = ""

                status = "Available" if total_price != "" else "Sold out"

                print("Room Name:", room_name)
                print("Price Without Breakfast:", total_price)
                print("Price With Breakfast:", breakfast_price_text)
                print("Status:", status)

                self.data.append({
                    "Room Name": room_name,
                    "Price Without Breakfast": total_price.replace('total',''),
                    "Price With Breakfast": breakfast_price_text.replace('total',''),
                    "Status": status,
                })

            except Exception as e:
                print("Error reading a room block:", e)

        self.driver.quit()
        self.write_to_csv()

    def clean_price(self, text):
        return ''.join(char for char in text if char in '¥0123456789, totalTOTAL').strip()

    def write_to_csv(self):
        with open('output/expedia_rooms.csv', mode='w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=["Room Name", "Price Without Breakfast","Price With Breakfast","Status"])
            writer.writeheader()
            writer.writerows(self.data)
        print("CSV file saved as 'expedia_rooms.csv'")


if __name__ == "__main__":
    scraper = ExpediaScraper()
    scraper.open_site()








