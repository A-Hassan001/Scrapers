import sys
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings

from procore_contracters.spiders.procore import ProcoreSpider  # Correct class import

def run_spider(state: str = "fl"):
    process = CrawlerProcess(get_project_settings())
    process.crawl(ProcoreSpider, state=state)
    process.start()

if __name__ == '__main__':
    state_code = sys.argv[1] if len(sys.argv) > 1 else "fl"
    run_spider(state=state_code)
