import os
import csv
from typing import Any

from slugify import slugify
from scrapy import Spider, Request


class AkronSpider(Spider):
    name = "akron"
    start_urls = ["https://www.akronlegalnews.com/notices/delinquent_taxes/no_results"]

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        os.makedirs("output", exist_ok=True)

    def parse(self, response, **kwargs):
        for link in response.css('li[style="font-size:12px; line-height:16px;"] a'):
            url = link.attrib.get("href", '')

            if not url:
                continue

            url_id = url.split('/')[-1]
            text = slugify(link.css('::text').get('')).upper()
            file_name = f"output/{text}-{url_id}.csv"
            yield Request(url=response.urljoin(url), callback=self.parcel_number, meta={'file_name': file_name})

    def parcel_number(self, response):
        parcel_numbers = response.css('div[style*="float:left;width:270px;"] p::text').re(r'•\s*(\d{7})')
        file_name = response.meta.get('file_name')
        self.write_csv(parcel_numbers, file_name)

    def write_csv(self, parcel_numbers, file_name):
        with open(file_name, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=['Parcel'])
            writer.writeheader()
            for number in parcel_numbers:
                writer.writerow({'Parcel': number})

        self.logger.info(f"Saved {len(parcel_numbers)} parcel numbers to {file_name}")


