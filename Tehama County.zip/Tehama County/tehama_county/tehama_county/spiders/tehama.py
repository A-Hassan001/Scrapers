import os
import glob
from typing import Iterable, Any

from scrapy import Spider, Request
from openpyxl import load_workbook, Workbook


class TehamaSpider(Spider):
    name = "tehama"
    start_url = "https://common1.mptsweb.com/MBC/tehama/tax/search"
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
    }

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        os.makedirs('output', exist_ok=True)
        input_files = glob.glob('input/*.xlsx')
        if input_files:
            self.input_file_name = os.path.basename(input_files[0])
            print(f"Found input file: {self.input_file_name}")
        else:
            self.input_file_name = None
            print("No Excel files found in 'input' folder.")

        self.user_input_data = self.read_excel_as_list_of_dicts(self.input_file_name) or []
        self.output_data = []

    def start_requests(self) -> Iterable[Any]:
        yield Request(url=self.start_url, headers=self.headers, callback=self.parse)

    def parse(self, response, **kwargs):
        for row in self.user_input_data:  # ['071-224-009-000', '071-224-014-000']:
            fee_parcel_id = (row.get('Fee Parcel') or '').replace('-', '').strip()  # row.replace('-', '').strip()
            if fee_parcel_id:
                detail_url = f'https://common1.mptsweb.com/MBC/tehama/tax/main/{fee_parcel_id}/2025/0000'
                yield Request(url=detail_url, headers=self.headers, callback=self.parse_details,
                              meta={'property_data': row})

    def parse_details(self, response):
        property_data = response.meta.get('property_data', '')

        address = response.css('#h2tab2 .dl-horizontal dt:contains("Address") + dd::text').get('').strip()
        property_data["Address"] = address

        yield property_data
        self.output_data.append(property_data)

    def read_excel_as_list_of_dicts(self, file_path):
        file_path = f'input/{file_path}'
        try:
            workbook = load_workbook(file_path)
        except FileNotFoundError:
            print(f"File '{file_path}' not exist.")
            return []
        except Exception as e:
            print(f"Error: {e}")
            return []

        sheet = workbook.active
        headers = [cell.value for cell in sheet[1]]
        data_list = []

        for row in sheet.iter_rows(min_row=2, values_only=True):
            row_dict = dict(zip(headers, row))
            data_list.append(row_dict)

        return data_list

    def write_output_to_excel(self):
        output_file_path = f'output/{next(iter((self.input_file_name or "").split(".")))} [Updated].xlsx'
        os.makedirs(os.path.dirname(output_file_path), exist_ok=True)

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Glenn Data"

        headers = ["Fee Parcel", "Address", "TaxDelYearCount", "ASMT Number", "FirstYearTaxDel", "Owner", "Taxes Owed"]
        sheet.append(headers)

        for item in self.output_data:
            sheet.append([item.get("Fee Parcel", ""), item.get("Address", ""), item.get("TaxDelYearCount", ""),
                          item.get("ASMT Number", ""), item.get("FirstYearTaxDel", ""), item.get("owner", ""),
                          item.get('taxes owed', '')])

        workbook.save(output_file_path)
        self.logger.info(f"Output saved successfully to {output_file_path}")

    def close(self, reason):
        self.write_output_to_excel()
