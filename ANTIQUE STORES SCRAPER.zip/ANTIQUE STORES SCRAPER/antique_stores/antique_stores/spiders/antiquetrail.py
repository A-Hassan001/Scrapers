import re
import usaddress
from collections import OrderedDict

from scrapy import Spider, Request


class AntiquestoresSpider(Spider):
    name = "antiquetrail"
    start_urls = ["https://antiquetrail.com/"]
    headers = {
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
    }
    custom_settings = {
        'CONCURRENT_REQUESTS': 8,
        'FEEDS': {
            f'output/antique_stores.csv': {
                'format': 'csv',
                'fields': ['Business Name', 'Phone Number', 'Address', 'City', 'State', 'Zip', 'Website',
                           'Facebook', 'Twitter', 'Instagram', 'Pinterest', 'Blog', 'Owner Name', 'Email' ],
                'overwrite': True
            }
        }
    }

    def parse(self, response, **kwargs):
        listing_states = response.css('#all-states-menu a::attr(href)').getall()
        for state_url in listing_states:
            yield Request(url=state_url, callback=self.stores_detail, headers = self.headers)

    def stores_detail(self, response):
        listing_stores = response.css('div[style="width: 49%; margin-bottom: 6px;"]')[1:]
        for store in listing_stores:
            item = OrderedDict()
            item['Business Name'] = store.css('strong::text').get('')
            item['Phone Number'] = store.css('a::attr(href)').re_first(r'^tel:(.*)', '')
            full_address = self.get_address(store)
            item['Address'] = full_address.get('street_address', '')    #store.css('div[style*="font-size: 12px"]::text').get('').strip()
            item['City'] = full_address.get('city', '')
            item['State'] = full_address.get('state', '')
            item['Zip'] = full_address.get('zip_code', '')
            item['Website'] = store.css('a[onclick*="captureClick"]::attr(href)').get('')    #css('::attr(href)').re_first(r'http[^\"]+', '')    #css('a[style="font: 16px Arial;"]::attr(href)').get('')
            item['Facebook'] = store.css('[title="Facebook"]::attr(href)').get('')
            item['Twitter'] = store.css('[title="Twitter"]::attr(href)').get('')
            item['Instagram'] = store.css('[title="Instagram"]::attr(href)').get('')
            item['Pinterest'] = store.css('[title="Pinterest"]::attr(href)').get('')
            item['Blog'] = store.css('[title="Blog"]::attr(href)').get('')

            if 'antiquetrail.com' in item.get('Website'):
                yield Request(url=item.get('Website'), callback=self.details_info, headers=self.headers, meta={'item': item})

            yield item

    def get_address(self, store):
        full_address = ' '.join([line.strip() for line in store.css('div[style*="font-family:Arial"]::text').getall() if line.strip()])
        try:
            return self.get_address_parts(address_string=full_address)
        except:
            full_address = re.sub(r'\(.*?\)', '', full_address).strip()

            # Simple fix for duplicated city/state/ZIP
            full_address = re.sub(r'([A-Za-z\s]+),?\s+([A-Z]{2})\s+(\d{5})\s+\1,?\s+\2\s+\3$', r'\1, \2 \3', full_address)

            try:
                return self.get_address_parts(address_string=full_address)
            except:
                return full_address

    def get_address_parts(self, address_string):
        address = usaddress.tag(address_string, tag_mapping={
            'Recipient': 'recipient',
            'AddressNumber': 'street_address',
            'AddressNumberPrefix': 'street_address',
            'AddressNumberSuffix': 'street_address',
            'StreetName': 'street_address',
            'StreetNamePreDirectional': 'street_address',
            'StreetNamePreModifier': 'street_address',
            'StreetNamePreType': 'street_address',
            'StreetNamePostDirectional': 'street_address',
            'StreetNamePostModifier': 'street_address',
            'StreetNamePostType': 'street_address',
            'CornerOf': 'street_address',
            'IntersectionSeparator': 'street_address',
            'LandmarkName': 'street_address',
            'USPSBoxGroupID': 'street_address',
            'USPSBoxGroupType': 'street_address',
            'USPSBoxID': 'street_address',
            'USPSBoxType': 'street_address',
            'BuildingName': 'street_address',
            'OccupancyType': 'street_address',
            'OccupancyIdentifier': 'street_address',
            'SubaddressIdentifier': 'street_address',
            'SubaddressType': 'street_address',
            'PlaceName': 'city',
            'StateName': 'state',
            'ZipCode': 'zip_code',
        })

        return address[0]

    def details_info(self, response):
        item = response.meta['item']
        contact_text = response.css('div#contact-name *::text').getall()
        item['Owner Name'] = ''.join(contact_text).replace('Contact:', '').strip()
        item['Email'] = response.css('a::attr(href)').re_first(r'^mailto:(.*)', '')
        yield item
