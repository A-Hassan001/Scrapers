import csv
from datetime import datetime
from typing import Iterable, Any
from collections import OrderedDict

import usaddress
from scrapy.http import Response
from scrapy import Spider, Request


class SepticServicesSpider(Spider):
    name = "septic_services"
    start_urls = ["https://septic.com/"]

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        self.output_file_name = f'output/septic_services {datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}.csv'

    def start_requests(self) -> Iterable[Request]:
        yield Request(url=self.start_urls[0], callback=self.parse)

    def parse(self, response: Response, **kwargs) -> Iterable[Request]:
        for location in response.css('area ::attr(href)').getall():
            yield Request(url=location, callback=self.parse_sub_location)

    def parse_sub_location(self, response: Response) -> Iterable[Request]:
        for sub_location in response.css('td[width="33%"] a ::attr(href)').getall():
            yield Request(url=sub_location, callback=self._parse_sub_location)

    def _parse_sub_location(self, response: Response) -> Iterable[Request]:
        for sub_location in  response.css('td[width="50%"] a::attr(href)').getall():
            yield Request(url=sub_location, callback=self.detail_page)

    def detail_page(self, response: Response) -> OrderedDict:
        full_address = ' '.join(next(iter(response.css('.business td'))).xpath('text()').getall()).strip()
        city_state_zip = next(reversed(full_address.split('\n')), '')
        parsed_address, address_type = usaddress.tag(city_state_zip)

        item = OrderedDict()

        item['Company Name'] = response.css('.business td b ::text').get('').strip()
        item['Address (full address)'] = full_address
        item['Phone'] = response.css('.business td:contains("Phone") ::text').get('').replace('Phone:', '').strip()
        item['Website'] = response.css('.business td:contains("Website:") ::text').get('').replace('Website:', '').strip()
        item['City'] = parsed_address.get('PlaceName', '') if isinstance(parsed_address, dict) else ''
        item['State'] = parsed_address.get('StateName', '') if isinstance(parsed_address, dict) else ''
        item['URL'] = response.url

        self.write_to_csv(data=item)
        yield item

    def write_to_csv(self, data: OrderedDict) -> None:
        with open(self.output_file_name, 'a', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['Company Name', 'Address (full address)', 'Phone', 'Website', 'City', 'State', 'URL']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            if csvfile.tell() == 0:
                writer.writeheader()  # Writes header once
            # Write the data row
            writer.writerow(data)