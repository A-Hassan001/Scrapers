import argparse, json, os, csv
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict
import statistics, re

from bs4 import BeautifulSoup
import requests

from playwright.sync_api import sync_playwright

@dataclass
class VanQuery:
    year: int
    make: str
    model: str
    trim: Optional[str] = None
    entry: Optional[str] = None
    power: Optional[str] = None
    conversion: Optional[str] = None
    miles: Optional[int] = None

@dataclass
class Listing:
    source: str
    title: str
    url: str
    price: float
    miles: Optional[int]
    year: Optional[int]

def parse_price(text):
    match = re.search(r"\\$([\\d,]+)", text)
    return float(match.group(1).replace(",", "")) if match else 0

def parse_miles(text):
    match = re.search(r"(\\d{1,3}(,\\d{3})*)\\s*miles", text.lower())
    return int(match.group(1).replace(",", "")) if match else None

def parse_year(text):
    match = re.search(r"\\b(20\\d{2}|19\\d{2})\\b", text)
    return int(match.group(1)) if match else None

def scrape_ams() -> List[Listing]:
    url = "https://www.amsvans.com/wheelchair-vans"
    listings = []
    r = requests.get(url, timeout=20)
    soup = BeautifulSoup(r.text, "lxml")

    for card in soup.select("div.inventory-item"):
        a = card.find("a", href=True)
        title = card.get_text(strip=True)
        href = a["href"] if a else "#"
        price = parse_price(card.get_text())
        miles = parse_miles(card.get_text())
        year = parse_year(card.get_text())
        listings.append(Listing("AMS Vans", title, f"https://www.amsvans.com{href}", price, miles, year))

    return listings


def scrape_unitedaccess() -> List[Listing]:
    url = "https://www.unitedaccess.com/us/en/inventory.html"
    r = requests.get(url, timeout=20)
    soup = BeautifulSoup(r.text, "lxml")
    listings = []
    for a in soup.select("a[href*='/us/en/vehicles/']"):
        title = a.get_text(strip=True)
        href = a['href']
        price = parse_price(title)
        miles = parse_miles(title)
        year = parse_year(title)
        listings.append(Listing("United Access", title, f"https://www.unitedaccess.com{href}", price, miles, year))
    return listings

def scrape_mobilityworks(playwright) -> List[Listing]:
    listings = []
    browser = playwright.chromium.launch()
    page = browser.new_page()
    page.goto("https://www.mobilityworks.com/inventory/search")
    page.wait_for_timeout(5000)
    cards = page.locator(".inventory-listing")
    for i in range(cards.count()):
        el = cards.nth(i)
        title = el.locator(".vehicle-title").text_content()
        price = parse_price(el.text_content())
        miles = parse_miles(el.text_content())
        href = el.locator("a").get_attribute("href")
        year = parse_year(title)
        if title and href:
            listings.append(Listing("MobilityWorks", title.strip(), f"https://www.mobilityworks.com{href}", price, miles, year))
    browser.close()
    return listings

def scrape_mobility316(playwright) -> List[Listing]:
    listings = []
    browser = playwright.chromium.launch()
    page = browser.new_page()
    page.goto("https://www.mobility316.com/vehicles-for-sale/")
    page.wait_for_timeout(5000)
    items = page.locator(".inventory-item")
    for i in range(items.count()):
        el = items.nth(i)
        title = el.locator(".title").text_content()
        price = parse_price(el.text_content())
        href = el.locator("a").get_attribute("href")
        year = parse_year(title)
        miles = parse_miles(el.text_content())
        listings.append(Listing("Mobility316", title.strip(), href, price, miles, year))
    browser.close()
    return listings

def main(args=None, return_listings=False):
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int)
    parser.add_argument("--make")
    parser.add_argument("--model")
    parser.add_argument("--trim")
    parser.add_argument("--entry")
    parser.add_argument("--power")
    parser.add_argument("--conversion")
    parser.add_argument("--miles", type=int)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--ams", action="store_true")
    parser.add_argument("--ua", action="store_true")
    parser.add_argument("--mw", action="store_true")
    parser.add_argument("--m316", action="store_true")
    args = parser.parse_args() if args is None else args

    query = VanQuery(args.year, args.make, args.model, args.trim, args.entry, args.power, args.conversion, args.miles)
    listings = []

    if args.demo:
        listings.append(Listing("DemoDealer", "2019 Chrysler Pacifica Touring L", "https://example.com", 45000, 42000, 2019))
    if args.ams:
        listings.extend(scrape_ams())
    if args.ua:
        listings.extend(scrape_unitedaccess())
    if args.mw or args.m316:
        with sync_playwright() as p:
            if args.mw:
                listings.extend(scrape_mobilityworks(p))
            if args.m316:
                listings.extend(scrape_mobility316(p))

    listings.sort(key=lambda x: x.price)
    for l in listings[:10]:
        print(f"[{l.source}] {l.title} | ${int(l.price):,} | {l.url}")

    out = [asdict(l) for l in listings]

    if not out:
        print("⚠️ No listings were found. Check your filters or source availability.")
        return [] if return_listings else None

    with open("van_results.json", "w") as f:
        json.dump(out, f, indent=2)

    with open("van_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=out[0].keys())
        writer.writeheader()
        writer.writerows(out)

    print(f"✅ Done. {len(out)} listings saved to van_results.csv")

    return out if return_listings else None

def run_search(year, make, model, trim, entry, power, conversion, miles, sources):
    from types import SimpleNamespace
    args = SimpleNamespace(
        year=year,
        make=make,
        model=model,
        trim=trim,
        entry=entry,
        power=power,
        conversion=conversion,
        miles=miles,
        demo=False,  # 👈 FIXED: Add this line to avoid AttributeError
        ams="AMS" in sources,
        ua="UnitedAccess" in sources,
        mw="MobilityWorks" in sources,
        m316="Mobility316" in sources,
    )
    return main(args, return_listings=True)

if __name__ == "__main__":
    main()

