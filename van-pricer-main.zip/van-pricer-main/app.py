import streamlit as st
import subprocess

st.title("Van Price Scraper 🛠️")

# Sidebar filters
year = st.selectbox("Year", list(range(2010, 2025))[::-1])
make = st.text_input("Make", "Chrysler")
model = st.text_input("Model", "Pacifica")
trim = st.text_input("Trim", "")
entry = st.selectbox("Entry Type", ["rear", "side"])
power = st.selectbox("Conversion Power", ["manual", "power"])
conversion = st.text_input("Conversion Brand", "BraunAbility")
miles = st.number_input("Max Miles", value=42000)

# Dealer checkboxes
st.markdown("### Select Dealerships to Scrape:")
ams = st.checkbox("AMS Vans", value=True)
ua = st.checkbox("United Access")
mw = st.checkbox("MobilityWorks")
m316 = st.checkbox("Mobility316")

# Run button
if st.button("🚀 Run Search"):
    cmd = [
        "python", "van_pricer.py",
        "--year", str(year),
        "--make", make,
        "--model", model,
        "--trim", trim,
        "--entry", entry,
        "--power", power,
        "--conversion", conversion,
        "--miles", str(miles)
    ]

    if ams: cmd.append("--ams")
    if ua: cmd.append("--ua")
    if mw: cmd.append("--mw")
    if m316: cmd.append("--m316")

    st.write("Running command:", " ".join(cmd))

    # Run the scraper
    result = subprocess.run(cmd, capture_output=True, text=True)

    # Show output
    st.code(result.stdout)

    # Show CSV preview
    try:
        import pandas as pd
        df = pd.read_csv("van_results.csv")
        st.dataframe(df)
    except Exception as e:
        st.error(f"CSV load error: {e}")
