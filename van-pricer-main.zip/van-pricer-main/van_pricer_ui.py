import streamlit as st
from datetime import datetime
from van_pricer import run_search  # This should match your backend scraper function

# --- Constants ---
CURRENT_YEAR = datetime.now().year
years = list(range(2005, CURRENT_YEAR + 1))
makes = ["Chrysler", "Dodge", "Honda", "Toyota"]

models_by_make = {
    "Chrysler": lambda year: ["Pacifica", "Voyager"] if year > 2015 else ["Town & Country"],
    "Dodge": lambda _: ["Grand Caravan"],
    "Honda": lambda _: ["Odyssey"],
    "Toyota": lambda _: ["Sienna"]
}

trims_by_model = {
    "Pacifica": ["Touring", "Touring L", "Touring L Plus", "Limited"],
    "Voyager": ["LX", "LXi"],
    "Town & Country": ["LX", "Touring", "Limited", "EX"],
    "Grand Caravan": ["SE", "SE Plus", "SXT", "GT"],
    "Odyssey": ["EX", "EX-L", "Touring", "Elite", "LX"],
    "Sienna": ["LE", "XLE", "XSE", "Limited", "CE", "L", "SE"]
}

entry_types = ["Side", "Rear"]
power_types = ["Manual", "Power"]
conversions = ["BraunAbility", "VMI", "Revability", "FR Conversions", "Freedom Motors", "AMS", "AutoAbility", "AmeriVan"]
sources = ["AMS", "MobilityWorks", "UnitedAccess", "Mobility316"]

# --- Streamlit UI ---
st.set_page_config(page_title="Wheelchair Van Market Pricer", layout="wide")
st.title("📊 Wheelchair Van Market Pricing Tool")

col1, col2 = st.columns(2)

with col1:
    year = st.selectbox("Year", years[::-1])
    make = st.selectbox("Make", makes)
    model_options = models_by_make[make](year)
    model = st.selectbox("Model", model_options)
    trim = st.selectbox("Trim", trims_by_model.get(model, []))

with col2:
    entry = st.selectbox("Entry", entry_types)
    power = st.selectbox("Power", power_types)
    conversion = st.selectbox("Conversion Brand", conversions)
    miles = st.number_input("Mileage", min_value=0, step=500, value=50000)

selected_sources = st.multiselect("Select Sources to Scrape", sources, default=sources)

if st.button("🔍 Search Market"):
    with st.spinner("Scraping listings from selected sources..."):
        listings = run_search(year, make, model, trim, entry.lower(), power.lower(), conversion, miles, selected_sources)

    if listings:
        prices = [x["price"] for x in listings if x.get("price")]
        if prices:
            st.success(f"Found {len(prices)} listings")
            st.metric("Average Price", f"${int(sum(prices)/len(prices)):,}")
            st.metric("Lowest Price", f"${min(prices):,}")
            st.metric("Highest Price", f"${max(prices):,}")

        for item in listings:
            st.write(f"**{item['title']}**")
            st.write(f"💲 ${item['price']:,} | [{item['source']}]({item['url']})")
            st.markdown("---")
    else:
        st.warning("No listings found or error in scraping.")

st.caption("Built with ❤️ to help you price your vans right.")
