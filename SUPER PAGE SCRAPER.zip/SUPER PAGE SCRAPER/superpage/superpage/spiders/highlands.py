import json
from collections import OrderedDict

import openpyxl
from scrapy import Request, Spider


class SuperpagesSpider(Spider):
    name = 'highlands'
    base_url = 'https://www.superpages.com/highlands-ranch-co'
    allowed_categories = ['INSURANCE']

    soax_auth_headers = {
        'X-SOAX-API-Secret': '62f43969-fa34-4a1b-a409-254b0d1f2b51',
        'Content-Type': 'application/json',
    }

    custom_settings = {
        'FEEDS': {
            'output/categories_ins.xlsx': {'format': 'xlsx', }},
        'FEED_EXPORTERS': {'xlsx': 'scrapy_xlsx.XlsxItemExporter', },
        'CONCURRENT_REQUESTS': 5,

        'RETRY_ENABLED': True,
        'RETRY_TIMES': 5,  # Total number of retries per request
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 522, 524, 408, 429],

    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.seen = set()
        self._load_existing_data('output/categories.xlsx')

    def start_requests(self):
        yield self.make_soax_request(url=self.base_url, callback=self.parse, meta_dict={})

    def parse(self, response, **kwargs):
        for category in response.css('section.popular-cats article'):
            main_category = category.css('h3::text').get()
            if not main_category:
                continue
            main_category = main_category.strip()
            if main_category not in self.allowed_categories:
                continue

            links = category.css('a::attr(href)').getall()
            for relative_url in links:
                if not relative_url:
                    continue
                sub_category = relative_url.strip('/').split('/')[-1].replace('-', ' ').title()
                full_url = f"https://www.superpages.com{relative_url}"
                yield self.make_soax_request(url=full_url, callback=self.parse_sub_categories, meta_dict={'main_category': main_category, 'sub_category': sub_category})

    def parse_sub_categories(self, response):
        main_category = response.meta.get("main_category", '')
        sub_category = response.meta.get("sub_category", '')
        category = f"{main_category} > {sub_category}"

        for item in response.css('div.section-wrapper'):
            detail_url = item.css('a.business-name::attr(href)').get()
            if not detail_url:
                continue
            detail_url = detail_url.strip()
            if detail_url in self.seen:
                continue
            self.seen.add(detail_url)

            meta = {
                'category': category,
                'item_name': item.css('a.business-name span::text').get(default='').strip(),
                'phone': item.css('span.call-number::text').get(default='').strip(),
                'website': item.css('.weblink-button::attr(href)').get(default='').strip(),
                'address': item.css('span.street-address::text').get(default='').strip(),
                'url': f"https://www.superpages.com{detail_url}"
            }

            yield self.make_soax_request(url=meta['url'], callback=self.details, meta_dict=meta)

        next_page = response.css('div.pagination a.next::attr(href)').get()
        if next_page:
            next_url = f"https://www.superpages.com{next_page}"
            yield self.make_soax_request(url=next_url, callback=self.parse_sub_categories, meta_dict=response.meta)

    def details(self, response):
        scripts = response.css('script[type="application/ld+json"]::text').get()
        data = json.loads(scripts) if scripts else {}

        item = OrderedDict()
        item['Category'] = response.meta.get('category', '')
        item['Name'] = response.meta.get('item_name', '')
        item['Phone'] = response.meta.get('phone', '')
        item['Email'] = data.get('email', '').replace('mailto:', '') if data.get('email') else ''
        item['Address'] = response.meta.get('address', '')
        item['Website Link'] = response.meta.get('website', '')
        item['URL'] = response.meta.get('url', '')

        yield item

    def _load_existing_data(self, filepath):
        wb = openpyxl.load_workbook(filepath, read_only=True)
        sheet = wb.active
        self.seen = {
            (row[-1] or '').strip()  # Get the last column (detail_url), strip whitespace
            for row in sheet.iter_rows(min_row=2, values_only=True)
        }

    def make_soax_request(self, url: str, callback, meta_dict=dict):
        form_data = {
            "url": 'https://ikman.lk',
            "redirect_url": url,
        }
        meta_dict.update({'handle_httpstatus_list': [404,403, 520, 521], 'url': url})
        return Request(url='https://scraping.soax.com/v1/unblocker/html', callback=callback, method='POST',
                      headers=self.soax_auth_headers, body=json.dumps(form_data),
                      meta=meta_dict, dont_filter=True)